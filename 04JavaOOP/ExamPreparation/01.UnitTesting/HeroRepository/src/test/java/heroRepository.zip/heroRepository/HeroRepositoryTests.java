package heroRepository;

import org.junit.Assert.*;
import org.junit.Test;

import java.util.Collection;

import static org.junit.Assert.*;

public class HeroRepositoryTests {
    //TODO: TEST ALL THE FUNCTIONALITY OF THE PROVIDED CLASS HeroRepository
    private HeroRepository data;
    private Hero hero;

    public void setUp(){
        this.data = new HeroRepository();
        this.hero = new Hero("Merry", 1);
    }

    //getCount
/*    @Test
    public void testGetCount(){
        this.data.create(hero);
        Collection<Hero> heroes = this.data.getHeroes();
        int count = this.data.getCount();
        assertEquals(heroes.size(), count);
    }*/

    @Test(expected = NullPointerException.class)
    public void testCreate(){
        this.data.create(null);
    }

/*    @Test(expected = NullPointerException.class)
    public void testCreate2(){
        String ex = "Hero with name %s already exists";
        this.data.create(hero);
        String ac = this.data.create(hero);
        assertEquals(ex, ac);
    }*/

/*    @Test
    public void testcreateSucc(){

        String s = this.data.create(this.hero);
        String ac = String.format("Successfully added hero %s with level %d", hero.getName(), hero.getLevel());
        assertEquals(ac, s);
    }*/

    @Test(expected = NullPointerException.class)
    public void testRemove(){
        this.data.remove(null);
    }

/*    @Test
    public void testgetHeroWithHighestLevel(){
        String s = this.data.create(this.hero);
        int merry = this.data.getHero("Merry").getLevel();
        int level = this.data.getHeroWithHighestLevel().getLevel();
        assertEquals(merry, level);
    }

    @Test(expected = UnsupportedOperationException.class)
    public void teset(){
        Collection<Hero> heroes = this.data.getHeroes();
        heroes.remove(null);
    }*/
}
